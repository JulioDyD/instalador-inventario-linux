#!/usr/bin/env bash
# Instala el agente como servicio systemd. Ejecutar desde una copia de confianza.
set -euo pipefail
umask 027

SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
SERVER_URL=""
INSTALL_DIR="/opt/inventario-telemetria"
CONFIG_DIR="/etc/inventario-telemetria"
STATE_DIR="/var/lib/inventario-telemetria"
SERVICE_USER="telemetry-agent"
STAGING_DIR=""

usage() {
  echo "Uso: sudo bash scripts/install-linux.sh [--server-url https://servidor] [--source /ruta/al/proyecto]"
}
while (($#)); do
  case "$1" in
    --server-url|--source)
      if (($# < 2)); then usage >&2; exit 2; fi
      if [[ "$1" == --source ]]; then SOURCE_DIR="$2"; else SERVER_URL="$2"; fi
      shift 2 ;;
    --help|-h) usage; exit 0 ;;
    *) usage >&2; exit 2 ;;
  esac
done
if ((EUID != 0)); then
  echo "Ejecute este instalador con sudo: debe crear el usuario, las rutas protegidas y el servicio." >&2
  exit 1
fi
for command in python3 systemctl useradd getent install; do
  command -v "$command" >/dev/null || { echo "Falta el comando requerido: $command" >&2; exit 1; }
done
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else "Se requiere Python >= 3.10")'
SOURCE_DIR="$(cd -- "$SOURCE_DIR" && pwd)"
for item in pyproject.toml telemetry_agent; do
  [[ -e "$SOURCE_DIR/$item" ]] || { echo "Falta $item en el proyecto de origen." >&2; exit 1; }
done
if ! getent passwd "$SERVICE_USER" >/dev/null; then
  useradd --system --user-group --home-dir "$STATE_DIR" --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER"
fi
install -d -o root -g root -m 0755 "$INSTALL_DIR"
install -d -o root -g "$SERVICE_USER" -m 0750 "$CONFIG_DIR"
install -d -o "$SERVICE_USER" -g "$SERVICE_USER" -m 0700 "$STATE_DIR"

if [[ ! -e "$CONFIG_DIR/agent.json" ]]; then
  if [[ -z "$SERVER_URL" ]]; then
    read -r -p "URL del servidor (https://...): " SERVER_URL
  fi
  read -r -s -p "Código de instalación (Enter para inventario general): " INSTALLATION_CODE
  echo
  ENROLLMENT_KEY=""
  if [[ -z "$INSTALLATION_CODE" ]]; then
    read -r -s -p "Clave general de inscripción (enrollment_key): " ENROLLMENT_KEY
    echo
    if [[ -z "$ENROLLMENT_KEY" ]]; then echo "La clave de inscripción no puede estar vacía." >&2; exit 1; fi
  fi
  # stdin carries both secrets; they never appear in arguments or output.
  printf '%s\0%s' "$INSTALLATION_CODE" "$ENROLLMENT_KEY" | python3 -c '
import json, os, sys
from urllib.parse import urlsplit
url, path, state = sys.argv[1:]
parsed = urlsplit(url)
loopback = parsed.hostname in {"127.0.0.1", "localhost", "::1"}
if (parsed.scheme not in {"https", "http"} or not parsed.hostname or
    (parsed.scheme == "http" and not loopback) or parsed.username or parsed.password or
    parsed.query or parsed.fragment):
    raise SystemExit("URL inválida: use HTTPS; HTTP sólo se permite en loopback.")
code, key = sys.stdin.read().split("\0")
if len(code) > 256 or any(not 33 <= ord(character) <= 126 for character in code):
    raise SystemExit("Código de instalación inválido: use texto ASCII sin espacios ni controles, de hasta 256 caracteres.")
if not code and not key:
    raise SystemExit("Indique un código de instalación o una clave general de inscripción.")
if any(ord(character) < 32 or ord(character) == 127 for character in key):
    raise SystemExit("La clave de inscripción no puede contener caracteres de control.")
config = {"server_url": url.rstrip("/"), "enrollment_key": key, "installation_code": code,
          "interval_seconds": 60, "state_path": state,
          "timeout_seconds": 15, "max_backoff_seconds": 300}
with open(path, "x", encoding="utf-8") as handle:
    json.dump(config, handle, indent=2)
    handle.write("\n")
' "$SERVER_URL" "$CONFIG_DIR/agent.json" "$STATE_DIR/identity.json"
  unset ENROLLMENT_KEY INSTALLATION_CODE
else
  echo "Actualización: se conservan configuración e identidad. No se reasigna el equipo a otra compañía, sede o grupo."
fi
chown root:"$SERVICE_USER" "$CONFIG_DIR/agent.json"
chmod 0640 "$CONFIG_DIR/agent.json"

STAGING_DIR="$(mktemp -d "$INSTALL_DIR/.source.XXXXXX")"
trap 'if [[ -n "$STAGING_DIR" && -d "$STAGING_DIR" ]]; then rm -rf -- "$STAGING_DIR"; fi' EXIT
for item in pyproject.toml README.md LICENSE; do
  if [[ -e "$SOURCE_DIR/$item" ]]; then cp -a -- "$SOURCE_DIR/$item" "$STAGING_DIR/"; fi
done
# These packages have only Python sources. Never copy local JSON/config/state files.
python3 -c '
from pathlib import Path
import shutil, sys
source, destination = map(Path, sys.argv[1:])
for package in ("telemetry_agent",):
    for path in (source / package).rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        target = destination / path.relative_to(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
' "$SOURCE_DIR" "$STAGING_DIR"
chown -R root:root "$STAGING_DIR"
chmod -R u=rwX,go=rX "$STAGING_DIR"

if [[ ! -x "$INSTALL_DIR/venv/bin/python" ]]; then
  python3 -m venv "$INSTALL_DIR/venv"
fi
# Build/install before stopping the current process. A failed pip leaves it running.
"$INSTALL_DIR/venv/bin/python" -m pip install --upgrade "${STAGING_DIR}[agent]"
# umask protects configuration, but the unprivileged service must read its runtime.
chown -R root:root "$INSTALL_DIR/venv"
chmod -R u=rwX,go=rX "$INSTALL_DIR/venv"
if systemctl cat telemetry-agent.service >/dev/null 2>&1; then
  systemctl stop telemetry-agent.service
fi
if [[ -d "$INSTALL_DIR/app" ]]; then rm -rf -- "$INSTALL_DIR/app"; fi
mv -- "$STAGING_DIR" "$INSTALL_DIR/app"
STAGING_DIR=""
cat > /etc/systemd/system/telemetry-agent.service <<'UNIT'
[Unit]
Description=Agente de telemetria de inventario
Wants=network-online.target
After=network-online.target

[Service]
Type=simple
User=telemetry-agent
Group=telemetry-agent
WorkingDirectory=/var/lib/inventario-telemetria
ExecStart=/opt/inventario-telemetria/venv/bin/python -m telemetry_agent --config /etc/inventario-telemetria/agent.json
Restart=on-failure
RestartSec=10
UMask=0077
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/inventario-telemetria
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
UNIT
chmod 0644 /etc/systemd/system/telemetry-agent.service
systemctl daemon-reload
systemctl enable --now telemetry-agent.service
echo "Agente instalado. Configuración e identidad existentes conservadas."
echo "Estado: sudo systemctl status telemetry-agent.service"
echo "Registro: sudo journalctl -u telemetry-agent.service -n 50 --no-pager"
