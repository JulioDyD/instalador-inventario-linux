"""Installable client for the equipment telemetry service."""

__version__ = "0.2.0"
