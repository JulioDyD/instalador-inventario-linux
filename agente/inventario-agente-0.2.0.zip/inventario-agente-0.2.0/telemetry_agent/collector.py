"""Best-effort hardware readings; unavailable sensors remain explicitly absent."""

from __future__ import annotations

from datetime import datetime, timezone
import logging
import math
from pathlib import Path
import platform
import subprocess
import time

try:
    import psutil
except ImportError:
    psutil = None

from telemetry_agent.config import AgentError


LOGGER = logging.getLogger(__name__)


def clean_serial(value: str) -> str | None:
    value = value.strip().strip("\x00").strip()
    normalized = "".join(character for character in value.casefold() if character.isalnum())
    placeholders = {
        "tobefilledbyoem", "defaultstring", "systemserialnumber", "serialnumber",
        "unknown", "none", "na", "notapplicable", "notspecified", "notavailable",
        "invalid", "oem", "0",
    }
    if not value or len(value) > 255 or normalized in placeholders or not normalized:
        return None
    if len(normalized) >= 4 and set(normalized) <= {"0", "f"}:
        return None
    if any(ord(character) < 32 for character in value):
        return None
    return value


def serial_number(system_name: str | None = None) -> str | None:
    system_name = system_name or platform.system()
    if system_name == "Linux":
        for filename in ("/sys/class/dmi/id/product_serial", "/sys/class/dmi/id/board_serial"):
            try:
                candidate = clean_serial(Path(filename).read_text(encoding="utf-8", errors="replace"))
                if candidate:
                    return candidate
            except OSError:
                continue
    elif system_name == "Windows":
        try:
            result = subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
                 "(Get-CimInstance -ClassName Win32_BIOS -ErrorAction Stop).SerialNumber"],
                capture_output=True,
                text=True,
                timeout=5,
                check=True,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            return clean_serial(result.stdout)
        except (OSError, subprocess.SubprocessError, UnicodeError):
            pass
    return None


class Collector:
    def __init__(self) -> None:
        if psutil is None:
            raise AgentError("Falta la dependencia psutil; instale el paquete con sus dependencias.")
        self._temperature_notice_logged = False

    def collect(self) -> dict:
        memory = psutil.virtual_memory()
        disks = []
        seen_mountpoints = set()
        for partition in psutil.disk_partitions(all=False):
            if partition.mountpoint in seen_mountpoints:
                continue
            seen_mountpoints.add(partition.mountpoint)
            try:
                usage = psutil.disk_usage(partition.mountpoint)
            except (OSError, psutil.Error):
                LOGGER.info("Se omitió un volumen que no está disponible para lectura.")
                continue
            disks.append({
                "device": partition.device,
                "mountpoint": partition.mountpoint,
                "total_bytes": int(usage.total),
                "free_bytes": int(usage.free),
                "used_percent": float(usage.percent),
            })
        temperatures = []
        read_temperatures = getattr(psutil, "sensors_temperatures", None)
        if read_temperatures:
            try:
                for sensor, readings in read_temperatures(fahrenheit=False).items():
                    for reading in readings:
                        if reading.current is not None and math.isfinite(reading.current):
                            temperatures.append({
                                "sensor": str(sensor),
                                "label": str(reading.label or ""),
                                "current_celsius": float(reading.current),
                            })
            except (OSError, psutil.Error, NotImplementedError):
                pass
        if not temperatures and not self._temperature_notice_logged:
            LOGGER.info("Temperatura no disponible: depende de sensores, permisos y soporte del sistema operativo.")
            self._temperature_notice_logged = True
        return {
            "collected_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "ram": {
                "total_bytes": int(memory.total),
                "available_bytes": int(memory.available),
                "used_percent": float(memory.percent),
            },
            "disks": disks,
            "temperatures": temperatures,
            "uptime_seconds": max(0.0, time.time() - psutil.boot_time()),
        }
