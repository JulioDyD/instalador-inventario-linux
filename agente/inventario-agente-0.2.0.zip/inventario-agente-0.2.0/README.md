# Agente de inventario para los equipos

Este paquete contiene el agente Python `telemetry_agent` y sus instaladores. Los equipos necesitan Python **3.10 o superior** y acceso a Internet para instalar las dependencias. No necesitan el backend, el panel, Node.js ni credenciales de Firebase.

Receptor de producción: `https://inventario-api-jryilooe3a-uc.a.run.app`

Panel: https://inventario-equipos-dyd-261117.web.app

Solicita al administrador un **código de instalación** para el grupo, compañía y sede correspondientes. Si el equipo debe quedar en el inventario general, deja el código vacío y utiliza la **clave general de inscripción vigente**. Sólo necesitas una de esas dos credenciales. La contraseña de acceso al panel no sirve para inscribir equipos. El ZIP es genérico: no contiene códigos ni claves reales.

## Linux: instalación nueva como servicio

Requisitos: `python3` con soporte `venv` y `pip`, systemd y permisos sudo. Extrae el ZIP y abre una terminal dentro de su carpeta `inventario-agente-0.2.0`:

```bash
sudo bash scripts/install-linux.sh --server-url https://inventario-api-jryilooe3a-uc.a.run.app
```

El instalador pide primero el código de instalación sin mostrarlo. Si pulsas Enter sin código, solicita la clave general, también oculta. Instala las dependencias y arranca `telemetry-agent.service`. El servicio se inicia con el sistema y vuelve a arrancar si el proceso falla. Se ejecuta como el usuario de servicio `telemetry-agent`, sin activar terminal ni reinicios remotos.

Comprobar el estado y los registros:

```bash
sudo systemctl status telemetry-agent.service
sudo journalctl -u telemetry-agent.service -n 50 --no-pager
```

La configuración queda en `/etc/inventario-telemetria/agent.json`; la identidad propia del equipo, en `/var/lib/inventario-telemetria/identity.json`.

## Windows: instalación nueva al arrancar

Requisitos: Python 3.10 o superior accesible como `python`, PowerShell 5.1 o superior y una consola de PowerShell abierta como administrador. Dentro de la carpeta extraída:

```powershell
.\scripts\install-windows.ps1 -ServerUrl "https://inventario-api-jryilooe3a-uc.a.run.app" -PythonExe "python"
```

El instalador pide primero el código, con entrada protegida. Si lo dejas vacío, pide la clave general con la misma protección. Instala las dependencias y crea e inicia la tarea `InventarioTelemetriaAgent` para el arranque de Windows. La tarea se ejecuta como SYSTEM; no habilita control remoto. Si Python tiene otra ubicación, usa su ruta absoluta en `-PythonExe`.

La configuración y la identidad quedan en `%ProgramData%\InventarioTelemetria`. El instalador Windows está incluido; no se ha verificado su ejecución nativa en Windows en este entorno.

## Aprobar el equipo

En el panel, inicia sesión como administrador y entra en **Solicitudes**. Revisa y aprueba cada equipo. Un código válido asigna la solicitud al grupo de destino y hereda su compañía, sede y políticas de monitoreo; no evita la aprobación. Sin código, la clave general crea la solicitud en **General**. Después de la aprobación comenzará a enviar métricas según la política del grupo; el intervalo predeterminado es de 60 segundos.

Un código incorrecto o revocado produce un error de inscripción: el agente no usa la clave general como alternativa ni envía el equipo a General. Solicita al administrador el código correcto y actualiza `installation_code` en la configuración privada. No publiques la configuración ni pegues códigos en comandos o registros.

Cada instalación genera un UUID y un token propios. Distribuye este ZIP de fuentes, nunca la carpeta de estado de otro equipo. Conserva la identidad de cada instalación para que sus reinicios no creen registros diferentes.

## Si ya existe una instalación

Los instaladores conservan la configuración y la identidad existentes. No vuelven a pedir código o clave y **no reasignan** un equipo registrado a otra compañía, sede o grupo. Pasar una URL nueva **no cambia** la instalación anterior ni crea un perfil paralelo. Revisa el receptor configurado antes de reutilizarlos para mover un equipo del entorno local a producción. Los cambios de asignación de un equipo ya registrado se hacen desde el panel; no borres su identidad para moverlo.

Las configuraciones anteriores sin `installation_code` siguen funcionando. Actualiza al agente 0.2.0 o posterior antes de añadir ese campo a una configuración antigua. La identidad UUID/token permanece en su archivo separado y se conserva en cada actualización.

## Prueba manual sin instalar servicio

Si sólo quieres probar el agente en primer plano, crea su entorno virtual e instala el paquete desde esta carpeta:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install '.[agent]'
cp agent-config.example.json agent.json
chmod 600 agent.json
```

Edita `agent.json` en un editor: para una ubicación concreta, coloca el código entregado por el administrador en `installation_code` y deja `enrollment_key` vacío. Para inventario general, deja `installation_code` vacío y sustituye la clave de ejemplo en `enrollment_key` por la clave vigente. La URL ya corresponde al receptor real. Después:

```bash
.venv/bin/python -m telemetry_agent --config agent.json --check-connection
.venv/bin/python -m telemetry_agent --config agent.json
```

La primera orden comprueba HTTPS sin crear identidad ni enviar métricas; no valida el código ni la clave de inscripción. La segunda solicita inscripción, espera aprobación y continúa enviando lecturas. Si existen ambos valores en una configuración, el agente utiliza exclusivamente el código, sin intentar la clave si falla. Detener esa terminal detiene el agente manual. En Windows, usa `.venv\Scripts\python.exe` para ejecutar el módulo.

La recopilación de temperatura y número de serie depende de los sensores y permisos que ofrezca el equipo. Si alguno no está disponible, la recepción de las demás métricas continúa.
