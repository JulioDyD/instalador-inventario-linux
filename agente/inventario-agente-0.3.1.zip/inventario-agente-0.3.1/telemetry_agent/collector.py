"""Best-effort hardware and network readings; unavailable values remain absent."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime, timezone
import ipaddress
import json
import logging
import math
from pathlib import Path
import platform
import re
import socket
import subprocess
import time

try:
    import psutil
except ImportError:
    psutil = None

from telemetry_agent.config import AgentError


LOGGER = logging.getLogger(__name__)
MAX_NETWORK_BYTES = 128 * 1024
MAX_SAFE_INTEGER = 2**53 - 1


def _positive_integer(value: object) -> int | None:
    if isinstance(value, int) and not isinstance(value, bool):
        return value if 0 < value <= MAX_SAFE_INTEGER else None
    if isinstance(value, float) and math.isfinite(value) and 0 < value <= MAX_SAFE_INTEGER and value.is_integer():
        return int(value)
    return None


def _mac_address(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.replace("-", ":")
    if re.fullmatch(r"(?:[0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}", value):
        return value.lower()
    return None


def collect_network() -> dict | None:
    """Read local interfaces without external requests or elevated commands."""
    read_addresses = getattr(psutil, "net_if_addrs", None)
    if not callable(read_addresses):
        return None
    try:
        addresses = read_addresses()
    except (OSError, psutil.Error, NotImplementedError):
        return None
    if not isinstance(addresses, Mapping):
        return None

    statistics = {}
    read_statistics = getattr(psutil, "net_if_stats", None)
    if callable(read_statistics):
        try:
            candidate = read_statistics()
            if isinstance(candidate, Mapping):
                statistics = candidate
        except (OSError, psutil.Error, NotImplementedError):
            pass

    link_families = tuple(
        family for family in (getattr(psutil, "AF_LINK", None), getattr(socket, "AF_PACKET", None))
        if family is not None
    )
    interfaces = []
    encoded_bytes = len(json.dumps({"interfaces": []}).encode("utf-8"))
    for name in dict.fromkeys((*addresses, *statistics)):
        # Omitting overlong names preserves identity: truncation can merge interfaces.
        if (
            not isinstance(name, str) or not 1 <= len(name) <= 128
            or not name.strip() or not name.isprintable()
            or len(name.encode("utf-16-le")) > 256
        ):
            continue
        ipv4_addresses = []
        ipv6_addresses = []
        mac_address = None
        interface_addresses = addresses.get(name, ())
        if not isinstance(interface_addresses, (list, tuple)):
            interface_addresses = ()
        for address in interface_addresses:
            family = getattr(address, "family", None)
            value = getattr(address, "address", None)
            if family in link_families:
                mac_address = mac_address or _mac_address(value)
                continue
            if not isinstance(value, str) or family not in (socket.AF_INET, socket.AF_INET6):
                continue
            try:
                if family == socket.AF_INET:
                    normalized = str(ipaddress.IPv4Address(value))
                    target = ipv4_addresses
                else:
                    normalized = str(ipaddress.IPv6Address(value.split("%", 1)[0]))
                    target = ipv6_addresses
            except ipaddress.AddressValueError:
                continue
            if normalized not in target and len(target) < 32:
                target.append(normalized)
        stats = statistics.get(name)
        is_up = getattr(stats, "isup", None)
        interface = {
            "name": name,
            "mac_address": mac_address,
            "ipv4_addresses": ipv4_addresses,
            "ipv6_addresses": ipv6_addresses,
            "is_up": is_up if isinstance(is_up, bool) else None,
            "speed_mbps": _positive_integer(getattr(stats, "speed", None)),
            "mtu": _positive_integer(getattr(stats, "mtu", None)),
        }
        added_bytes = len(json.dumps(interface, allow_nan=False).encode("utf-8")) + (2 if interfaces else 0)
        if encoded_bytes + added_bytes > MAX_NETWORK_BYTES:
            break
        interfaces.append(interface)
        encoded_bytes += added_bytes
        if len(interfaces) == 128:
            break
    return {"interfaces": interfaces}


def clean_serial(value: str) -> str | None:
    value = value.strip().strip("\x00").strip()
    normalized = "".join(character for character in value.casefold() if character.isalnum())
    placeholders = {
        "tobefilledbyoem", "defaultstring", "systemserialnumber", "serialnumber",
        "unknown", "none", "na", "notapplicable", "notspecified", "notavailable",
        "invalid", "oem", "0",
    }
    if not value or len(value) > 255 or normalized in placeholders or not normalized:
        return None
    if len(normalized) >= 4 and set(normalized) <= {"0", "f"}:
        return None
    if any(ord(character) < 32 for character in value):
        return None
    return value


def serial_number(system_name: str | None = None) -> str | None:
    system_name = system_name or platform.system()
    if system_name == "Linux":
        for filename in ("/sys/class/dmi/id/product_serial", "/sys/class/dmi/id/board_serial"):
            try:
                candidate = clean_serial(Path(filename).read_text(encoding="utf-8", errors="replace"))
                if candidate:
                    return candidate
            except OSError:
                continue
    elif system_name == "Windows":
        try:
            result = subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
                 "(Get-CimInstance -ClassName Win32_BIOS -ErrorAction Stop).SerialNumber"],
                capture_output=True,
                text=True,
                timeout=5,
                check=True,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            return clean_serial(result.stdout)
        except (OSError, subprocess.SubprocessError, UnicodeError):
            pass
    return None


class Collector:
    def __init__(self) -> None:
        if psutil is None:
            raise AgentError("Falta la dependencia psutil; instale el paquete con sus dependencias.")
        self._temperature_notice_logged = False

    def collect(self) -> dict:
        memory = psutil.virtual_memory()
        disks = []
        seen_mountpoints = set()
        for partition in psutil.disk_partitions(all=False):
            if partition.mountpoint in seen_mountpoints:
                continue
            seen_mountpoints.add(partition.mountpoint)
            try:
                usage = psutil.disk_usage(partition.mountpoint)
            except (OSError, psutil.Error):
                LOGGER.info("Se omitió un volumen que no está disponible para lectura.")
                continue
            disks.append({
                "device": partition.device,
                "mountpoint": partition.mountpoint,
                "total_bytes": int(usage.total),
                "free_bytes": int(usage.free),
                "used_percent": float(usage.percent),
            })
        temperatures = []
        read_temperatures = getattr(psutil, "sensors_temperatures", None)
        if read_temperatures:
            try:
                for sensor, readings in read_temperatures(fahrenheit=False).items():
                    for reading in readings:
                        if reading.current is not None and math.isfinite(reading.current):
                            temperatures.append({
                                "sensor": str(sensor),
                                "label": str(reading.label or ""),
                                "current_celsius": float(reading.current),
                            })
            except (OSError, psutil.Error, NotImplementedError):
                pass
        if not temperatures and not self._temperature_notice_logged:
            LOGGER.info("Temperatura no disponible: depende de sensores, permisos y soporte del sistema operativo.")
            self._temperature_notice_logged = True
        return {
            "collected_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "ram": {
                "total_bytes": int(memory.total),
                "available_bytes": int(memory.available),
                "used_percent": float(memory.percent),
            },
            "disks": disks,
            "temperatures": temperatures,
            "network": collect_network(),
            "uptime_seconds": max(0.0, time.time() - psutil.boot_time()),
        }
