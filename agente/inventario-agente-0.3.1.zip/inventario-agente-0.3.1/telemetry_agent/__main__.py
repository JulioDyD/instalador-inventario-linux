"""Run with ``python -m telemetry_agent --config agent.json``."""

from __future__ import annotations

import argparse
from dataclasses import replace
from datetime import datetime, timezone
import json
import logging
from pathlib import Path
import signal
import threading

from telemetry_agent import __version__
from telemetry_agent.client import TelemetryAgent
from telemetry_agent.config import AgentError, Config, Identity, write_example
from telemetry_agent.transport import check_connection


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Agente de telemetría de equipos Windows y Linux.")
    parser.add_argument("--version", action="version", version=__version__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--config", type=Path, help="Archivo JSON de configuración.")
    source.add_argument("--init-config", type=Path, metavar="PATH", help="Crear una configuración de ejemplo privada.")
    parser.add_argument("--once", action="store_true", help="Ejecutar un ciclo y finalizar.")
    parser.add_argument("--check-connection", action="store_true", help="Comprobar la salud del receptor sin inscripción ni métricas; salida JSON.")
    parser.add_argument("--remote-control", action="store_true", help="Habilitar control remoto durante la ejecución continua.")
    parser.add_argument("--json-result", action="store_true", help="Con --once, escribir un resultado JSON sin credenciales.")
    parser.add_argument("--expected-device-id", help="Validar la identidad existente antes de consultar el agente local.")
    parser.add_argument("--expected-server-url", help="Validar el receptor del agente local antes de comunicar.")
    args = parser.parse_args(argv)
    if args.check_connection and (not args.config or args.once or args.json_result or args.remote_control):
        parser.error("--check-connection requiere --config y no admite --once, --json-result ni --remote-control.")
    if args.remote_control and (args.once or args.json_result or not args.config):
        parser.error("--remote-control requiere --config y ejecución continua, sin --once ni --json-result.")
    if args.json_result and (not args.once or not args.config):
        parser.error("--json-result requiere --once y --config.")
    if args.expected_device_id or args.expected_server_url:
        if not (args.json_result or args.check_connection) or not args.expected_device_id or not args.expected_server_url:
            parser.error("La consulta local requiere --once --json-result o --check-connection y ambas validaciones de identidad y receptor.")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logger = logging.getLogger("telemetry_agent")
    identity: Identity | None = None
    connection_mode = "system"

    def connection_result(ok: bool, message: str) -> None:
        print(json.dumps({"device_id": identity.device_id if identity else None,
            "ok": ok, "mode": connection_mode,
            "checked_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "message": message}, ensure_ascii=False))
    try:
        if args.init_config:
            write_example(args.init_config)
            logger.info("Configuración de ejemplo creada; configure el servidor y un código de instalación o una clave de inscripción.")
            return 0
        config = Config.load(args.config)
        connection_mode = config.connection.mode
        if args.remote_control:
            config = replace(config, remote_control_enabled=True)
        if config.remote_control_enabled and (args.once or args.json_result):
            # Existing one-shot panel queries remain metrics-only even when
            # the installation opts into continuous remote control in JSON.
            config = replace(config, remote_control_enabled=False)
        if args.expected_device_id:
            identity = Identity.load_existing(config.state_path)
            if identity.device_id != args.expected_device_id or config.server_url != args.expected_server_url:
                raise AgentError("La identidad o el receptor local no coincide con la consulta solicitada.")
        elif not args.check_connection:
            identity = Identity.load_or_create(config.state_path)
        if args.check_connection:
            result = check_connection(config)
            connection_result(result["ok"], result["message"])
            return 0 if result["ok"] else 1
        agent = TelemetryAgent(config, identity)
        if args.json_result:
            current_status = agent.run_cycle()
            if current_status == "active" and agent.last_received_at:
                outcome = "sent"
                message = "El receptor confirmó una nueva lectura de telemetría."
            elif current_status in {"pending", "disabled", "rejected"}:
                outcome = current_status
                message = {
                    "pending": "El equipo está pendiente de aprobación; no se enviaron métricas.",
                    "disabled": "El equipo está desactivado; no se enviaron métricas.",
                    "rejected": "La solicitud del equipo está rechazada; no se enviaron métricas.",
                }[current_status]
            else:
                raise AgentError("El receptor no confirmó una nueva lectura de telemetría.")
            print(json.dumps({
                "device_id": identity.device_id, "outcome": outcome,
                "received_at": agent.last_received_at if outcome == "sent" else None,
                "message": message,
            }, ensure_ascii=False))
            return 0
        stop_event = threading.Event()

        def stop(signum, frame):
            stop_event.set()

        previous_handlers = {}
        for signum in (signal.SIGINT, signal.SIGTERM):
            previous_handlers[signum] = signal.signal(signum, stop)
        try:
            return agent.run(stop_event, once=args.once)
        finally:
            for signum, previous in previous_handlers.items():
                signal.signal(signum, previous)
    except AgentError as exc:
        logger.error("%s", exc)
        if args.check_connection:
            connection_result(False, str(exc))
        if args.json_result:
            print(json.dumps({
                "device_id": identity.device_id if identity else None,
                "outcome": "error", "received_at": None, "message": str(exc),
            }, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
