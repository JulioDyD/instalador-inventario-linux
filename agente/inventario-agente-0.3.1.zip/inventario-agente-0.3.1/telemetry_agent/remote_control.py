"""Opt-in outgoing remote control. The receptor never runs local commands.

No Linux-only modules are imported at module load, preserving Windows metrics.
Jobs are claimed by the server once and executed at most once per agent process.
"""

from __future__ import annotations

import copy
from datetime import datetime
import codecs
import json
import logging
import math
import os
from pathlib import Path
import platform
import re
import signal
import struct
import subprocess
import sys
import threading
import time
import uuid

import psutil

from telemetry_agent.config import AgentError, Config, Identity


LOGGER = logging.getLogger(__name__)
CHUNK_BYTES = 16 * 1024
BUFFER_BYTES = 64 * 1024
INPUT_BYTES = 4 * 1024
ORPHAN_SECONDS = 30
REBOOT_ARGV = ("/usr/bin/systemctl", "--no-ask-password", "reboot")
KINDS = {"system_info", "reboot", "terminal_open", "terminal_input", "terminal_interrupt", "terminal_close", "terminal_resize"}


def _text(value: str, maximum: int = CHUNK_BYTES, tail: bool = False) -> str:
    data = value.encode("utf-8", errors="replace")
    return (data[-maximum:] if tail else data[:maximum]).decode("utf-8", errors="ignore")


def _uuid(value: object) -> bool:
    try:
        return isinstance(value, str) and str(uuid.UUID(value)) == value
    except (ValueError, TypeError, AttributeError):
        return False


def _expiry(value: object) -> float:
    if not isinstance(value, str) or len(value) > 64:
        raise ValueError("expiry")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("timezone")
    result = parsed.timestamp()
    if not math.isfinite(result):
        raise ValueError("expiry")
    return result


def _dimensions(cols: object, rows: object) -> tuple[int, int]:
    if type(cols) is not int or not 20 <= cols <= 240 or type(rows) is not int or not 5 <= rows <= 100:
        raise ValueError("dimensions")
    return cols, rows


def runtime_info() -> dict:
    try:
        if os.name == "posix":
            import pwd
            user = pwd.getpwuid(os.geteuid()).pw_name
        else:
            import getpass
            user = getpass.getuser()
    except (KeyError, OSError):
        user = "desconocido"
    return {"os": _text(platform.system(), 64), "user": _text(user, 128),
            "elevated": bool(hasattr(os, "geteuid") and os.geteuid() == 0)}


def system_info() -> str:
    """A fixed allowlist: never environment, process arguments or project files."""
    memory = psutil.virtual_memory()
    return json.dumps({
        "hostname": platform.node(), "os": platform.system(), "release": platform.release(),
        "architecture": platform.machine(), "cpu_count": os.cpu_count(),
        "ram_total_bytes": int(memory.total), "ram_available_bytes": int(memory.available),
        "runtime": runtime_info(),
    }, ensure_ascii=False, sort_keys=True)


def shell_environment() -> tuple[str, dict[str, str]]:
    import pwd
    account = pwd.getpwuid(os.geteuid())
    home = account.pw_dir
    if not os.path.isdir(home) or not os.access(home, os.R_OK | os.X_OK):
        home = "/tmp"
    return home, {
        "PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": home,
        "USER": account.pw_name, "LOGNAME": account.pw_name,
        "LANG": "C.UTF-8", "TERM": "xterm", "SHELL": "/bin/bash",
        "PS1": "agent$ ", "HISTFILE": "/dev/null", "HISTSIZE": "0",
    }


class SecretFilter:
    """Redact known local secrets even when PTY reads split a secret in two."""
    def __init__(self, secrets: list[str]) -> None:
        self.secrets = sorted({secret for secret in secrets if secret}, key=len, reverse=True)
        self.carry = ""

    def feed(self, value: str, final: bool = False) -> str:
        value = self.carry + value
        self.carry = ""
        for secret in self.secrets:
            value = value.replace(secret, "[redactado]")
        keep = 0
        for secret in self.secrets:
            for length in range(1, min(len(secret), len(value) + 1)):
                if length > keep and value.endswith(secret[:length]):
                    keep = length
        if keep:
            self.carry = value[-keep:]
            value = value[:-keep]
        if final and self.carry:
            value += "[redactado]"
            self.carry = ""
        return value


class LocalControlLock:
    """A separate stable lock inode, never the private identity file itself."""
    def __init__(self, config: Config, identity: Identity) -> None:
        self.path = config.state_path.parent / f".{identity.device_id}.remote-control.lock"
        self.descriptor: int | None = None

    def acquire(self) -> bool:
        descriptor = None
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            descriptor = os.open(self.path, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0), 0o600)
            if os.name == "posix":
                import fcntl
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                os.fchmod(descriptor, 0o600)
            elif os.name == "nt":
                import msvcrt
                if os.fstat(descriptor).st_size == 0:
                    os.write(descriptor, b"0")
                os.lseek(descriptor, 0, os.SEEK_SET)
                msvcrt.locking(descriptor, msvcrt.LK_NBLCK, 1)
            else:
                raise OSError
            self.descriptor = descriptor
            return True
        except OSError:
            if descriptor is not None:
                os.close(descriptor)
            return False

    def release(self) -> None:
        if self.descriptor is not None:
            os.close(self.descriptor)
            self.descriptor = None


class LinuxTerminal:
    """One real controlling PTY with persistent shell state and foreground SIGINT."""
    def __init__(self, cols: int, rows: int) -> None:
        if not sys.platform.startswith("linux"):
            raise OSError("PTY no disponible")
        import pty
        import fcntl
        import termios
        self.master, slave = pty.openpty()
        self.decoder = codecs.getincrementaldecoder("utf-8")("replace")
        self.process: subprocess.Popen | None = None
        self.closed = False
        try:
            _dimensions(cols, rows)
            fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
            os.set_blocking(self.master, False)
            home, environment = shell_environment()
            # The fixed helper runs Python code only in the new child. Avoid
            # preexec_fn/fork callbacks in the agent's multithreaded process.
            helper = "import os,fcntl,termios;fcntl.ioctl(0,termios.TIOCSCTTY,0);os.execve('/bin/bash',['/bin/bash','--noprofile','--norc','-i'],dict(os.environ))"
            self.process = subprocess.Popen(
                [sys.executable, "-I", "-S", "-c", helper],
                stdin=slave, stdout=slave, stderr=slave, cwd=home, env=environment,
                start_new_session=True, close_fds=True,
            )
        except BaseException:
            os.close(self.master)
            self.closed = True
            raise
        finally:
            os.close(slave)

    def read_output(self) -> str:
        if self.closed:
            return ""
        parts: list[bytes] = []
        size = 0
        while size < BUFFER_BYTES:
            try:
                value = os.read(self.master, min(4096, BUFFER_BYTES - size))
                if not value:
                    break
                parts.append(value)
                size += len(value)
            except (BlockingIOError, OSError):
                break
        return self.decoder.decode(b"".join(parts))

    def alive(self) -> bool:
        return not self.closed and self.process is not None and self.process.poll() is None

    def write(self, value: str) -> None:
        data = value.encode("utf-8")
        if len(data) > INPUT_BYTES or not self.alive():
            raise OSError("Entrada no disponible")
        # Inputs are small; a blocked PTY must fail rather than stall polling.
        if os.write(self.master, data) != len(data):
            raise OSError("Entrada parcial")

    def interrupt(self) -> None:
        self.write("\x03")

    def resize(self, cols: int, rows: int) -> None:
        import fcntl
        import termios
        _dimensions(cols, rows)
        fcntl.ioctl(self.master, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))

    def close(self) -> None:
        if self.closed:
            return
        # Bash job control may create separate process groups. Kill descendants
        # as well as the shell group, without changing uid or using sudo.
        children = []
        if self.process is not None:
            try:
                children = psutil.Process(self.process.pid).children(recursive=True)
            except psutil.Error:
                pass
            for child in reversed(children):
                try:
                    child.terminate()
                except psutil.Error:
                    pass
            try:
                os.killpg(self.process.pid, signal.SIGHUP)
            except (OSError, ProcessLookupError):
                pass
            try:
                self.process.wait(timeout=0.5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=0.5)
            for child in children:
                try:
                    if child.is_running():
                        child.kill()
                except psutil.Error:
                    pass
        os.close(self.master)
        self.closed = True


def reboot_runner(argv: tuple[str, ...]) -> subprocess.CompletedProcess:
    home, environment = shell_environment()
    return subprocess.run(argv, capture_output=True, text=True, timeout=15,
                          cwd=home, env=environment, stdin=subprocess.DEVNULL, check=False)


class RemoteControlWorker:
    def __init__(self, config: Config, identity: Identity, api, *, clock=time.monotonic,
                 wall_clock=time.time, run_reboot=reboot_runner, terminal_factory=LinuxTerminal,
                 information=system_info, capabilities: dict | None = None) -> None:
        self.config, self.identity, self.api = config, identity, api
        self.clock, self.wall_clock = clock, wall_clock
        self.run_reboot, self.terminal_factory, self.information = run_reboot, terminal_factory, information
        linux = sys.platform.startswith("linux")
        self.capabilities = capabilities if capabilities is not None else {
            "terminal": linux and os.access("/bin/bash", os.X_OK),
            "reboot": linux and os.access(REBOOT_ARGV[0], os.X_OK), "system_info": True,
        }
        self.runtime = runtime_info()
        self.instance_id = str(uuid.uuid4())
        self._lock = threading.RLock()
        self._singleton = LocalControlLock(config, identity)
        self._stop = threading.Event()
        self._threads: list[threading.Thread] = []
        self._results: dict[str, dict] = {}
        self._executed: dict[str, float] = {}
        self._last_contact = self.clock()
        self._terminal = None
        self._session_id: str | None = None
        self._session_expiry = 0.0
        self._status = "closed"
        self._message = ""
        self._buffer = ""
        self._seq = -1
        self._report: dict | None = None
        self._unacknowledged_report: dict | None = None
        self._redactor = SecretFilter([config.enrollment_key, config.installation_code, identity.token])

    def start(self) -> bool:
        if not self.config.remote_control_enabled or self._threads:
            return False
        if not self._singleton.acquire():
            LOGGER.warning("Otro proceso controla esta identidad; la telemetría continúa sin control remoto.")
            return False
        self._stop.clear()
        self._last_contact = self.clock()
        for target, name in [(self._run, "agent-control-poll"), (self._watchdog, "agent-control-watchdog")]:
            thread = threading.Thread(target=target, name=name, daemon=True)
            self._threads.append(thread)
            thread.start()
        return True

    def stop(self) -> None:
        self._stop.set()
        with self._lock:
            self._close_terminal("Control remoto detenido.")
        for thread in self._threads:
            if thread is not threading.current_thread():
                thread.join(timeout=6)
        self._threads.clear()
        self._singleton.release()

    def _run(self) -> None:
        while not self._stop.is_set():
            self._stop.wait(self.poll_once())

    def _watchdog(self) -> None:
        while not self._stop.wait(0.1):
            with self._lock:
                self._maintain()

    def _append(self, value: str) -> None:
        self._buffer = _text(self._buffer + value, BUFFER_BYTES, tail=True)

    def _close_terminal(self, message: str, failed: bool = False) -> None:
        if self._terminal is not None:
            self._append(self._redactor.feed(self._terminal.read_output(), final=True))
            self._terminal.close()
            self._terminal = None
        if self._session_id is not None:
            self._status = "failed" if failed else "closed"
            self._message = message

    def _maintain(self) -> None:
        # Once a lease has expired plus this safety window, any replay is
        # rejected by its original expires_at before execution, without an
        # unbounded lifetime set of terminal keystroke IDs.
        for identifier, expiry in list(self._executed.items()):
            if self.wall_clock() > expiry + 60:
                self._executed.pop(identifier, None)
        if self._terminal is None:
            return
        self._append(self._redactor.feed(self._terminal.read_output()))
        if not self._terminal.alive():
            self._close_terminal("La sesión del sistema terminó.")
        elif self.clock() - self._last_contact > ORPHAN_SECONDS:
            self._close_terminal("Sesión cerrada al perder contacto con el receptor.", failed=True)
        elif self.wall_clock() >= self._session_expiry:
            self._close_terminal("La autorización de la sesión caducó.")

    def _terminal_report(self) -> dict | None:
        if self._unacknowledged_report is not None:
            return copy.deepcopy(self._unacknowledged_report)
        if self._session_id is None:
            return None
        changed = self._report is None or self._buffer or self._report["status"] != self._status or self._report.get("message", "") != self._message
        if changed:
            fragment = _text(self._buffer)
            self._buffer = self._buffer[len(fragment):]
            self._seq += 1
            self._report = {"id": self._session_id, "seq": self._seq, "output": fragment, "status": self._status}
            if self._message:
                self._report["message"] = self._message
        self._unacknowledged_report = copy.deepcopy(self._report)
        return copy.deepcopy(self._unacknowledged_report)

    def _payload(self) -> dict:
        self._maintain()
        payload = {
            "instance_id": self.instance_id, "capabilities": self.capabilities, "runtime": self.runtime,
            "results": [], "terminal": self._terminal_report(),
        }
        # JSON escaping can expand terminal control bytes sixfold. Send fewer
        # results if needed to stay below the receiver's 256 KiB body limit;
        # every unsent result remains queued until an exchange ACKs it.
        for result in list(self._results.values())[:10]:
            payload["results"].append(copy.deepcopy(result))
            if len(json.dumps(payload, allow_nan=False).encode("utf-8")) > 240 * 1024:
                payload["results"].pop()
                break
        return payload

    def _validate(self, response: object) -> dict:
        if not isinstance(response, dict) or set(response) != {"device_id", "poll_after_seconds", "acknowledged_results", "jobs", "terminal"}:
            raise ValueError("response")
        if response["device_id"] != self.identity.device_id or type(response["poll_after_seconds"]) is not int or response["poll_after_seconds"] not in (1, 3):
            raise ValueError("device")
        acks = response["acknowledged_results"]
        jobs = response["jobs"]
        if not isinstance(acks, list) or len(acks) > 10 or not all(_uuid(item) for item in acks):
            raise ValueError("ack")
        if not isinstance(jobs, list) or len(jobs) > 1:
            raise ValueError("jobs")
        terminal = response["terminal"]
        if terminal is not None:
            if not isinstance(terminal, dict) or set(terminal) != {"id", "expires_at", "cols", "rows"} or not _uuid(terminal["id"]):
                raise ValueError("terminal")
            _expiry(terminal["expires_at"])
            _dimensions(terminal["cols"], terminal["rows"])
        for job in jobs:
            if not isinstance(job, dict) or set(job) - {"id", "kind", "session_id", "input", "cols", "rows", "lease_token", "expires_at"}:
                raise ValueError("job")
            if not _uuid(job.get("id")) or job.get("kind") not in KINDS:
                raise ValueError("job kind")
            if not isinstance(job.get("lease_token"), str) or not re.fullmatch(r"[A-Za-z0-9_-]{32,256}", job["lease_token"]):
                raise ValueError("lease")
            _expiry(job.get("expires_at"))
            kind = job["kind"]
            allowed = {"id", "kind", "lease_token", "expires_at"}
            if kind.startswith("terminal_"):
                allowed.add("session_id")
                if not _uuid(job.get("session_id")):
                    raise ValueError("session")
            if kind in {"terminal_open", "terminal_resize"}:
                allowed.update({"cols", "rows"})
                _dimensions(job.get("cols"), job.get("rows"))
            if kind == "terminal_input":
                allowed.add("input")
                if not isinstance(job.get("input"), str) or len(job["input"].encode("utf-8")) > INPUT_BYTES:
                    raise ValueError("input")
            if set(job) - allowed:
                raise ValueError("job fields")
        return response

    def _result(self, job: dict, status: str, message: str, output: str | None = None, exit_code: int | None = None) -> None:
        value = {"id": job["id"], "lease_token": job["lease_token"], "status": status, "message": message}
        if output is not None:
            value["output"] = _text(SecretFilter([self.config.enrollment_key, self.config.installation_code, self.identity.token]).feed(output, final=True))
        if exit_code is not None:
            value["exit_code"] = exit_code
        self._results[job["id"]] = value

    def _execute(self, job: dict, descriptor: dict | None) -> None:
        if job["id"] in self._executed or job["id"] in self._results:
            return
        self._executed[job["id"]] = _expiry(job["expires_at"])
        if _expiry(job["expires_at"]) <= self.wall_clock():
            self._result(job, "failed", "La solicitud caducó antes de su ejecución.")
            return
        kind = job["kind"]
        try:
            if kind == "system_info":
                if not self.capabilities["system_info"]:
                    raise OSError
                self._result(job, "completed", "Información del sistema consultada.", self.information())
            elif kind == "reboot":
                if not self.capabilities["reboot"] or self._terminal is not None:
                    raise OSError
                outcome = self.run_reboot(REBOOT_ARGV)
                if type(outcome.returncode) is not int:
                    raise OSError
                success = outcome.returncode == 0
                self._result(job, "completed" if success else "failed",
                             "Solicitud de reinicio entregada al sistema." if success else "El sistema rechazó el reinicio con los permisos actuales.",
                             exit_code=outcome.returncode)
            elif kind == "terminal_open":
                if not self.capabilities["terminal"] or descriptor is None or descriptor["id"] != job["session_id"] or self._terminal is not None:
                    raise OSError
                if _expiry(descriptor["expires_at"]) <= self.wall_clock():
                    raise OSError
                self._session_id, self._session_expiry = descriptor["id"], _expiry(descriptor["expires_at"])
                self._seq, self._report, self._unacknowledged_report = -1, None, None
                self._buffer, self._message = "", ""
                self._redactor = SecretFilter([self.config.enrollment_key, self.config.installation_code, self.identity.token])
                self._terminal = self.terminal_factory(job["cols"], job["rows"])
                self._status = "open"
                self._result(job, "completed", "Terminal abierta con el usuario del agente.")
            elif kind == "terminal_close":
                # A null descriptor already revoked/closed this shell before
                # the close job arrived. Closing again is safely idempotent.
                if self._terminal is not None and self._session_id != job["session_id"]:
                    raise OSError
                self._close_terminal("Terminal cerrada por su administrador.")
                self._result(job, "completed", "Terminal cerrada.")
            else:
                if self._terminal is None or not self._terminal.alive() or self._session_id != job["session_id"]:
                    raise OSError
                if kind == "terminal_input":
                    self._terminal.write(job["input"])
                elif kind == "terminal_interrupt":
                    self._terminal.interrupt()
                elif kind == "terminal_resize":
                    self._terminal.resize(job["cols"], job["rows"])
                self._result(job, "completed", "Acción de terminal aplicada.")
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError, psutil.Error):
            if kind == "terminal_open":
                self._close_terminal("No se pudo abrir la terminal.", failed=True)
            self._result(job, "failed", "No se pudo ejecutar la acción con los permisos actuales del agente.")

    def poll_once(self) -> int:
        """One bounded exchange; results/PTY fragments survive uncertain replies."""
        with self._lock:
            payload = self._payload()
        try:
            response = self._validate(self.api.poll_control(payload))
        except Exception as exc:
            # Never log response bodies, inputs, exception text or credentials.
            with self._lock:
                if getattr(exc, "status", None) in (401, 403):
                    self._close_terminal("El receptor revocó la autorización.", failed=True)
                self._maintain()
            return 3
        with self._lock:
            if self._stop.is_set():
                return 3
            self._last_contact = self.clock()
            self._unacknowledged_report = None
            for identifier in response["acknowledged_results"]:
                # Only results actually present in this exchange may be ACKed.
                if identifier in {item["id"] for item in payload["results"]}:
                    self._results.pop(identifier, None)
            descriptor = response["terminal"]
            if descriptor is None or descriptor["id"] != self._session_id:
                self._close_terminal("El receptor cerró la sesión.")
                sent_terminal = payload["terminal"]
                sent_final = sent_terminal is not None and sent_terminal["id"] == self._session_id and sent_terminal["status"] in {"closed", "failed"}
                # Null revokes the shell, not its pending output. Keep the
                # session ID until the last final fragment was sent in an
                # exchange whose response arrived successfully.
                if descriptor is None and sent_final and self._terminal is None and not self._buffer:
                    self._session_id = None
                    self._report = None
            if descriptor is not None and descriptor["id"] == self._session_id:
                self._session_expiry = _expiry(descriptor["expires_at"])
            self._maintain()
            for job in response["jobs"]:
                self._execute(job, descriptor)
            if self._session_id is not None and (self._buffer or self._status in {"closed", "failed"}):
                return 1
            return response["poll_after_seconds"]
