"""Authenticated enrollment, status checks and bounded telemetry delivery."""

from __future__ import annotations

import http.client
import json
import logging
import platform
import random
import socket
import threading
import uuid
from urllib import error, request

from telemetry_agent import __version__
from telemetry_agent.collector import Collector, serial_number
from telemetry_agent.config import AgentError, Config, Identity
from telemetry_agent.transport import build_opener, NoRedirect as _NoRedirect


LOGGER = logging.getLogger(__name__)


class RemoteError(AgentError):
    def __init__(self, status: int | None = None, *, enrollment: bool = False, installation_code: bool = False):
        self.status = status
        if status == 401 and installation_code:
            message = "El código de instalación es inválido o está revocado (HTTP 401); no se usó la clave general y se conserva la identidad local."
        elif status == 401 and enrollment:
            message = "La clave de inscripción es inválida o está vencida (HTTP 401); se conserva la identidad local."
        elif status == 401:
            message = "El servidor rechazó la credencial (HTTP 401); se conserva la identidad local."
        elif status is not None:
            message = f"El servidor respondió HTTP {status}; se conserva la identidad local."
        else:
            message = "No se pudo contactar al servidor o su respuesta no es válida."
        super().__init__(message)


class APIClient:
    def __init__(self, config: Config, identity: Identity) -> None:
        self.config = config
        self.identity = identity
        self.opener = build_opener(config)

    def _request(self, method: str, path: str, payload: dict | None = None, enroll: bool = False, timeout: float | None = None) -> dict:
        headers = {
            "Authorization": f"Bearer {self.identity.token}",
            "Accept": "application/json",
            "User-Agent": f"equipment-telemetry-agent/{__version__}",
        }
        if enroll:
            if self.config.installation_code:
                headers["X-Installation-Code"] = self.config.installation_code
            elif self.config.enrollment_key:
                headers["X-Enrollment-Key"] = self.config.enrollment_key
            else:
                raise AgentError("El equipo necesita inscripción: configure installation_code o enrollment_key.")
        data = None
        if payload is not None:
            try:
                data = json.dumps(payload, allow_nan=False).encode("utf-8")
            except (TypeError, ValueError):
                raise AgentError("La lectura del equipo contiene valores no válidos.") from None
            headers["Content-Type"] = "application/json"
        req = request.Request(self.config.server_url + path, data=data, headers=headers, method=method)
        try:
            with self.opener.open(req, timeout=self.config.timeout_seconds if timeout is None else timeout) as response:
                raw = response.read(262145)
                if len(raw) > 262144:
                    raise RemoteError()
                result = json.loads(raw)
                if not isinstance(result, dict):
                    raise RemoteError()
                return result
        except error.HTTPError as exc:
            status = exc.code
            exc.close()
            raise RemoteError(status, enrollment=enroll, installation_code=enroll and bool(self.config.installation_code)) from None
        except (error.URLError, OSError, http.client.HTTPException, ValueError, UnicodeError):
            raise RemoteError() from None

    def get_status(self) -> dict:
        return self._request("GET", f"/api/v1/devices/{self.identity.device_id}/status")

    def enroll(self, payload: dict) -> dict:
        return self._request("POST", "/api/v1/enroll", payload, enroll=True)

    def send_snapshot(self, payload: dict) -> dict:
        result = self._request("POST", f"/api/v1/devices/{self.identity.device_id}/telemetry", payload)
        if result.get("accepted") is not True or not isinstance(result.get("received_at"), str):
            raise RemoteError()
        return result

    def poll_control(self, payload: dict) -> dict:
        return self._request("POST", f"/api/v1/devices/{self.identity.device_id}/control/poll", payload,
                             timeout=min(self.config.timeout_seconds, 5))


class TelemetryAgent:
    def __init__(self, config: Config, identity: Identity, api: APIClient | None = None, collector: Collector | None = None) -> None:
        self.config = config
        self.identity = identity
        self.api = api if api is not None else APIClient(config, identity)
        self.collector = collector if collector is not None else Collector()
        self.interval_seconds = config.interval_seconds
        self.last_received_at: str | None = None
        self._last_status: str | None = None
        self._enrollment_payload: dict | None = None

    def enrollment_payload(self) -> dict:
        if self._enrollment_payload is None:
            self._enrollment_payload = {
                "device_id": self.identity.device_id,
                "hostname": socket.gethostname(),
                "serial_number": serial_number(),
                "os": platform.system(),
                "os_version": platform.release(),
                "agent_version": __version__,
                "interval_seconds": self.config.interval_seconds,
            }
        return self._enrollment_payload

    def _apply_status(self, response: dict) -> str:
        status = response.get("status")
        interval = response.get("interval_seconds")
        offline_after = response.get("offline_after_seconds")
        if (
            response.get("device_id") != self.identity.device_id
            or status not in {"pending", "active", "disabled", "rejected"}
            or type(interval) is not int or not 10 <= interval <= 86400
            or type(offline_after) is not int or offline_after <= 0
        ):
            raise RemoteError()
        self.interval_seconds = interval
        if status != self._last_status:
            LOGGER.info("Estado del equipo en el servidor: %s.", status)
            self._last_status = status
        return status

    def run_cycle(self) -> str:
        self.last_received_at = None
        # A running approved agent gets configuration in the telemetry ACK.
        # Pending/disabled agents poll authorization without sending readings.
        if self._last_status != "active":
            try:
                response = self.api.get_status()
            except RemoteError as exc:
                if exc.status != 404:
                    raise
                response = self.api.enroll(self.enrollment_payload())
            if self._apply_status(response) != "active":
                return self._last_status
        try:
            snapshot = {**self.collector.collect(), "sample_id": str(uuid.uuid4())}
        except (OSError, RuntimeError):
            raise AgentError("No se pudo completar la lectura de telemetría del equipo.") from None
        try:
            acknowledgement = self.api.send_snapshot(snapshot)
        except RemoteError as exc:
            if exc.status in {403, 404}:
                self._last_status = None
                # Keep identity: a disabled device must never register as new.
                if exc.status == 403:
                    return self._apply_status(self.api.get_status())
            raise
        self._apply_status(acknowledgement)
        self.last_received_at = acknowledgement.get("received_at")
        LOGGER.info("Telemetría recibida por el servidor.")
        return self._last_status

    def retry_delay(self, failures: int) -> float:
        ceiling = min(self.config.max_backoff_seconds, min(self.interval_seconds, 30) * 2 ** min(max(0, failures - 1), 16))
        return random.uniform(ceiling / 2, ceiling)

    def run(self, stop_event: threading.Event, once: bool = False) -> int:
        worker = None
        if self.config.remote_control_enabled and not once:
            from telemetry_agent.remote_control import RemoteControlWorker
            worker = RemoteControlWorker(self.config, self.identity, APIClient(self.config, self.identity))
            worker.start()
        try:
            return self._run_telemetry(stop_event, once)
        finally:
            if worker is not None:
                worker.stop()

    def _run_telemetry(self, stop_event: threading.Event, once: bool) -> int:
        failures = 0
        while not stop_event.is_set():
            try:
                self.run_cycle()
                failures = 0
                delay = self.interval_seconds * random.uniform(0.95, 1.05)
            except AgentError as exc:
                LOGGER.warning("%s", exc)
                failures += 1
                if once:
                    return 1
                delay = self.retry_delay(failures)
            if once:
                return 0
            stop_event.wait(delay)
        return 0
