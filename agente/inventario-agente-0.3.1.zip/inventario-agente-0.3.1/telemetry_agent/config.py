"""Validated configuration and private, persistent equipment identity."""

from __future__ import annotations

import json
import ipaddress
import os
from pathlib import Path
import re
import secrets
import tempfile
from dataclasses import dataclass, field
from urllib.parse import urlsplit
import uuid


class AgentError(Exception):
    """An operational error whose message is safe to put in service logs."""


class ConfigError(AgentError):
    pass


def validate_installation_code(value: object) -> str:
    if not isinstance(value, str) or len(value) > 256 or any(not 33 <= ord(character) <= 126 for character in value):
        raise ConfigError("installation_code debe ser texto ASCII sin espacios ni controles, de hasta 256 caracteres, o estar vacío.")
    return value


def _integer(value: object, name: str, minimum: int, maximum: int) -> int:
    if type(value) is not int or not minimum <= value <= maximum:
        raise ConfigError(f"{name} debe ser un entero entre {minimum} y {maximum}.")
    return value


def validate_server_url(value: object) -> str:
    if not isinstance(value, str) or not value or len(value) > 2048 or value != value.strip():
        raise ConfigError("server_url debe ser una URL HTTP o HTTPS válida.")
    try:
        parsed = urlsplit(value)
        port = parsed.port
        host = parsed.hostname
    except ValueError:
        raise ConfigError("server_url debe ser una URL HTTP o HTTPS válida.") from None
    if (
        parsed.scheme not in {"http", "https"}
        or not host
        or parsed.username is not None
        or parsed.password is not None
        or "?" in value
        or "#" in value
        or "\\" in value
        or (port is not None and port == 0)
        or any(ord(character) < 33 or ord(character) == 127 for character in value)
    ):
        raise ConfigError("server_url debe usar HTTP(S), sin credenciales, consulta ni fragmento.")
    if parsed.scheme == "http" and host.lower() not in {"localhost", "127.0.0.1", "::1"}:
        raise ConfigError("Se requiere HTTPS para servidores remotos; HTTP solo permite loopback.")
    return value.rstrip("/")


def validate_proxy_url(value: object) -> str:
    message = "proxy_url debe ser una URL HTTP sin credenciales, ruta, consulta ni fragmento."
    if not isinstance(value, str) or not value or len(value) > 2048 or value != value.strip():
        raise ConfigError(message)
    try:
        parsed = urlsplit(value)
        port, hostname = parsed.port, parsed.hostname
    except ValueError:
        raise ConfigError(message) from None
    if (parsed.scheme != "http" or not hostname or parsed.username is not None or parsed.password is not None
            or parsed.path not in {"", "/"} or "?" in value or "#" in value
            or (port is not None and not 1 <= port <= 65535)
            or any(ord(character) < 33 or ord(character) == 127 for character in value)
            or "\\" in value):
        raise ConfigError(message)
    return value


@dataclass(frozen=True)
class ConnectionSettings:
    mode: str = "system"
    vpn_interface: str | None = None
    proxy_url: str | None = None

    @classmethod
    def load(cls, value: object) -> ConnectionSettings:
        if not isinstance(value, dict) or value.keys() - {"mode", "vpn_interface", "proxy_url"}:
            raise ConfigError("connection debe ser un objeto con campos reconocidos.")
        mode = value.get("mode")
        if not isinstance(mode, str) or mode not in {"system", "direct", "vpn", "proxy"}:
            raise ConfigError("connection.mode debe ser system, direct, vpn o proxy.")
        interface, proxy = value.get("vpn_interface"), value.get("proxy_url")
        if mode == "vpn":
            if not isinstance(interface, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,15}", interface, flags=re.ASCII):
                raise ConfigError("vpn_interface debe identificar una interfaz Linux de entre 1 y 15 caracteres ASCII.")
        elif interface is not None:
            raise ConfigError("vpn_interface sólo se admite en el modo vpn.")
        if mode == "proxy":
            proxy = validate_proxy_url(proxy)
        elif proxy is not None:
            raise ConfigError("proxy_url sólo se admite en el modo proxy.")
        return cls(mode, interface, proxy)


def validate_connection_target(server_url: str, connection: ConnectionSettings) -> None:
    if urlsplit(server_url).scheme != "http" or connection.mode != "proxy":
        return
    host = urlsplit(connection.proxy_url).hostname
    try:
        loopback = ipaddress.ip_address(host).is_loopback
    except ValueError:
        loopback = host.lower() == "localhost"
    if not loopback:
        raise ConfigError("Un receptor HTTP local sólo admite un proxy de loopback; use HTTPS para un proxy remoto.")


@dataclass(frozen=True)
class Config:
    server_url: str
    enrollment_key: str = field(repr=False)
    interval_seconds: int
    state_path: Path
    timeout_seconds: int = 15
    max_backoff_seconds: int = 60
    remote_control_enabled: bool = False
    connection: ConnectionSettings = field(default_factory=ConnectionSettings)
    installation_code: str = field(default="", repr=False)

    @classmethod
    def load(cls, filename: str | Path) -> Config:
        path = Path(filename).expanduser().resolve()
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            raise ConfigError("No se pudo leer la configuración JSON del agente.") from None
        if not isinstance(raw, dict):
            raise ConfigError("La configuración debe ser un objeto JSON.")
        known = {"server_url", "enrollment_key", "installation_code", "interval_seconds", "state_path", "timeout_seconds", "max_backoff_seconds", "remote_control_enabled", "connection"}
        if raw.keys() - known:
            raise ConfigError("La configuración contiene campos no reconocidos.")
        server_url = validate_server_url(raw.get("server_url"))
        key = raw.get("enrollment_key", "")
        if not isinstance(key, str) or any(ord(character) < 32 or ord(character) == 127 for character in key):
            raise ConfigError("enrollment_key debe ser texto sin caracteres de control.")
        installation_code = validate_installation_code(raw.get("installation_code", ""))
        state_name = raw.get("state_path", "state/identity.json")
        if not isinstance(state_name, str) or not state_name.strip():
            raise ConfigError("state_path debe ser una ruta de archivo.")
        state_path = Path(state_name).expanduser()
        if not state_path.is_absolute():
            state_path = path.parent / state_path
        if state_path.resolve() == path:
            raise ConfigError("state_path y el archivo de configuración deben ser diferentes.")
        remote_control = raw.get("remote_control_enabled", False)
        if type(remote_control) is not bool:
            raise ConfigError("remote_control_enabled debe ser booleano.")
        connection = ConnectionSettings.load(raw["connection"]) if "connection" in raw else ConnectionSettings()
        validate_connection_target(server_url, connection)
        return cls(
            server_url=server_url,
            enrollment_key=key,
            interval_seconds=_integer(raw.get("interval_seconds", 60), "interval_seconds", 10, 86400),
            state_path=state_path,
            timeout_seconds=_integer(raw.get("timeout_seconds", 15), "timeout_seconds", 1, 120),
            max_backoff_seconds=_integer(raw.get("max_backoff_seconds", 60), "max_backoff_seconds", 1, 86400),
            remote_control_enabled=remote_control,
            connection=connection,
            installation_code=installation_code,
        )


def write_example(filename: str | Path) -> None:
    """Create a new example without replacing an existing configuration."""
    payload = {
        "server_url": "http://127.0.0.1:8000",
        "enrollment_key": "REPLACE_WITH_SERVER_ENROLLMENT_KEY",
        "installation_code": "",
        "interval_seconds": 60,
        "state_path": "state/identity.json",
        "timeout_seconds": 15,
        "max_backoff_seconds": 60,
        "remote_control_enabled": False,
        "connection": {"mode": "system", "vpn_interface": None, "proxy_url": None},
    }
    path = Path(filename).expanduser()
    try:
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
            handle.write("\n")
    except FileExistsError:
        raise ConfigError("El archivo de configuración ya existe; no se sobrescribió.") from None
    except OSError:
        raise ConfigError("No se pudo crear el ejemplo de configuración.") from None


@dataclass(frozen=True)
class Identity:
    device_id: str
    token: str

    @classmethod
    def load_existing(cls, path: Path) -> Identity:
        """Read an enrolled installation without creating or rotating its identity."""
        return cls._read(path)

    @classmethod
    def load_or_create(cls, path: Path) -> Identity:
        """Publish a complete private file atomically and never replace an identity.

        Linking the temporary file exclusively also prevents concurrent first starts
        from creating two different identities. Existing corrupt files fail closed.
        """
        temporary_name: str | None = None
        try:
            if path.is_symlink():
                raise ConfigError("El archivo de identidad no puede ser un enlace simbólico.")
            if path.exists():
                return cls._read(path)
            path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            identity = cls(str(uuid.uuid4()), secrets.token_urlsafe(32))
            descriptor, temporary_name = tempfile.mkstemp(prefix=".identity-", dir=path.parent)
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                os.chmod(temporary_name, 0o600)
                json.dump({"device_id": identity.device_id, "token": identity.token}, handle)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            try:
                os.link(temporary_name, path)
            except FileExistsError:
                return cls._read(path)
            return identity
        except OSError:
            raise ConfigError("No se pudo leer o guardar la identidad privada del equipo.") from None
        finally:
            if temporary_name is not None:
                try:
                    os.unlink(temporary_name)
                except OSError:
                    pass

    @classmethod
    def _read(cls, path: Path) -> Identity:
        try:
            if path.is_symlink():
                raise ValueError
            raw = json.loads(path.read_text(encoding="utf-8"))
            device_id = raw["device_id"]
            token = raw["token"]
            if not isinstance(device_id, str) or str(uuid.UUID(device_id)) != device_id:
                raise ValueError
            if not isinstance(token, str) or not re.fullmatch(r"[A-Za-z0-9_-]{32,256}", token):
                raise ValueError
            os.chmod(path, 0o600)
            return cls(device_id, token)
        except (OSError, UnicodeError, ValueError, KeyError, TypeError):
            raise ConfigError("La identidad local es ilegible o inválida; no se generó una identidad nueva.") from None
