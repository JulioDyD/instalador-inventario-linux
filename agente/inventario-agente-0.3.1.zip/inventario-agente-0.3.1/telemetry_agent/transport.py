"""Shared, instance-local urllib transport; never changes system networking."""

from __future__ import annotations

from functools import partial
import errno
import http.client
import json
import socket
import ssl
import sys
from urllib import error, request
from urllib.parse import urlsplit

from telemetry_agent.config import AgentError, Config, ConnectionSettings, validate_connection_target


HEALTH_BYTES = 16 * 1024
SUCCESS = "Conexión con el receptor verificada."
INVALID_HEALTH = "El receptor no devolvió una respuesta de salud válida."
VPN_MISSING = "La interfaz VPN configurada no está disponible."
VPN_PERMISSION = "El sistema no permite vincular la conexión a la interfaz VPN."
VPN_UNSUPPORTED = "El modo VPN por interfaz sólo está disponible en Linux."
TLS_ERROR = "No se pudo verificar la conexión TLS con el receptor."
NETWORK_ERROR = "No se pudo conectar con el receptor usando la configuración guardada."
HTTP_ERROR = "El receptor rechazó la comprobación de conexión."


class TransportError(AgentError):
    """Only fixed, credential-free messages may cross the transport boundary."""


class NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class ForcedProxyHandler(request.ProxyHandler):
    """Explicit means explicit: NO_PROXY and OS bypass lists do not apply."""
    def __init__(self, proxy_url: str) -> None:
        self.hostport = urlsplit(proxy_url).netloc
        super().__init__({"http": proxy_url, "https": proxy_url})

    def proxy_open(self, req, proxy, scheme):
        # The validated HTTP proxy has no userinfo. For HTTPS, Request keeps
        # the original host as CONNECT target; stdlib performs TLS afterward.
        req.set_proxy(self.hostport, "http")
        return None


def _vpn_supported() -> None:
    if not sys.platform.startswith("linux") or not hasattr(socket, "SO_BINDTODEVICE"):
        raise TransportError(VPN_UNSUPPORTED)


def _bound_socket(host: str, port: int, timeout: float, interface: str) -> socket.socket:
    _vpn_supported()
    try:
        socket.if_nametoindex(interface)
    except OSError:
        raise TransportError(VPN_MISSING) from None
    # DNS remains the OS resolver. Every resulting data socket is bound; no
    # default-interface retry is allowed, including IPv4/IPv6 retries.
    addresses = socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM)
    last_error = None
    for family, socktype, protocol, _, address in addresses:
        connection = socket.socket(family, socktype, protocol)
        try:
            connection.settimeout(timeout)
            try:
                connection.setsockopt(socket.SOL_SOCKET, socket.SO_BINDTODEVICE, interface.encode("ascii") + b"\0")
            except OSError as exc:
                if exc.errno in {errno.EPERM, errno.EACCES}:
                    raise TransportError(VPN_PERMISSION) from None
                if exc.errno in {errno.ENODEV, errno.ENXIO}:
                    raise TransportError(VPN_MISSING) from None
                raise TransportError(NETWORK_ERROR) from None
            connection.connect(address)
            return connection
        except TransportError:
            connection.close()
            raise
        except OSError as exc:
            connection.close()
            last_error = exc
    if last_error is not None:
        raise last_error
    raise OSError("No resolved endpoint")


class _VPNHTTPConnection(http.client.HTTPConnection):
    def __init__(self, *args, interface: str, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.interface = interface

    def connect(self) -> None:
        if self._tunnel_host:
            raise TransportError(NETWORK_ERROR)
        self.sock = _bound_socket(self.host, self.port, self.timeout, self.interface)


class _VPNHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, *args, interface: str, context: ssl.SSLContext, **kwargs) -> None:
        super().__init__(*args, context=context, **kwargs)
        self.interface, self.tls_context = interface, context

    def connect(self) -> None:
        if self._tunnel_host:
            raise TransportError(NETWORK_ERROR)
        raw = _bound_socket(self.host, self.port, self.timeout, self.interface)
        try:
            self.sock = self.tls_context.wrap_socket(raw, server_hostname=self.host)
        except BaseException:
            raw.close()
            raise


class _VPNHTTPHandler(request.HTTPHandler):
    def __init__(self, interface: str) -> None:
        super().__init__()
        self.connection = partial(_VPNHTTPConnection, interface=interface)

    def http_open(self, req):
        return self.do_open(self.connection, req)


class _VPNHTTPSHandler(request.HTTPSHandler):
    def __init__(self, interface: str, context: ssl.SSLContext) -> None:
        super().__init__(context=context)
        self.connection = partial(_VPNHTTPSConnection, interface=interface, context=context)

    def https_open(self, req):
        return self.do_open(self.connection, req)


def build_opener(config: Config):
    # Revalidate direct dataclass construction as well as JSON-loaded configs.
    connection = ConnectionSettings.load({"mode": config.connection.mode,
        "vpn_interface": config.connection.vpn_interface, "proxy_url": config.connection.proxy_url})
    validate_connection_target(config.server_url, connection)
    if connection.mode == "vpn":
        _vpn_supported()
    context = ssl.create_default_context()
    context.set_alpn_protocols(["http/1.1"])
    if connection.mode == "system":
        proxies = request.ProxyHandler()
    elif connection.mode == "proxy":
        proxies = ForcedProxyHandler(connection.proxy_url)
    else:
        proxies = request.ProxyHandler({})
    handlers = [NoRedirect(), proxies]
    if connection.mode == "vpn":
        handlers.extend([_VPNHTTPHandler(connection.vpn_interface), _VPNHTTPSHandler(connection.vpn_interface, context)])
    else:
        handlers.append(request.HTTPSHandler(context=context))
    return request.build_opener(*handlers)


def check_connection(config: Config) -> dict:
    """Unauthenticated GET only. This function never reads any identity file."""
    try:
        opener = build_opener(config)
        health = request.Request(config.server_url + "/health", headers={"Accept": "application/json"}, method="GET")
        with opener.open(health, timeout=min(config.timeout_seconds, 5)) as response:
            raw = response.read(HEALTH_BYTES + 1)
            if len(raw) > HEALTH_BYTES:
                return {"ok": False, "message": INVALID_HEALTH}
            result = json.loads(raw)
            if response.status != 200 or not isinstance(result, dict) or result.get("ok") is not True or result.get("runtime") != "node":
                return {"ok": False, "message": INVALID_HEALTH}
        return {"ok": True, "message": SUCCESS}
    except TransportError as exc:
        return {"ok": False, "message": str(exc)}
    except error.HTTPError as exc:
        exc.close()
        return {"ok": False, "message": HTTP_ERROR}
    except (ssl.SSLError, error.URLError) as exc:
        tls = isinstance(exc, ssl.SSLError) or isinstance(getattr(exc, "reason", None), ssl.SSLError)
        return {"ok": False, "message": TLS_ERROR if tls else NETWORK_ERROR}
    except (ValueError, UnicodeError):
        return {"ok": False, "message": INVALID_HEALTH}
    except (OSError, http.client.HTTPException):
        return {"ok": False, "message": NETWORK_ERROR}
