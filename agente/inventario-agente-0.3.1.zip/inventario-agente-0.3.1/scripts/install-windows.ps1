#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$ServerUrl = '',
    [string]$SourceDir = (Split-Path -Parent $PSScriptRoot),
    [string]$PythonExe = 'python'
)
$ErrorActionPreference = 'Stop'
$InstallDir = Join-Path $env:ProgramData 'InventarioTelemetria'
$ConfigDir = Join-Path $InstallDir 'config'
$StateDir = Join-Path $InstallDir 'state'
$ConfigPath = Join-Path $ConfigDir 'agent.json'
$AppDir = Join-Path $InstallDir 'app'
$TaskName = 'InventarioTelemetriaAgent'
$StageDir = $null

function Set-PrivateDirectory([string]$Path) {
    $acl = New-Object System.Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sidText in @('S-1-5-18', 'S-1-5-32-544')) {
        $sid = New-Object System.Security.Principal.SecurityIdentifier($sidText)
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $sid, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
        $acl.AddAccessRule($rule)
    }
    Set-Acl -LiteralPath $Path -AclObject $acl
}

function Set-PrivateFile([string]$Path) {
    $acl = New-Object System.Security.AccessControl.FileSecurity
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sidText in @('S-1-5-18', 'S-1-5-32-544')) {
        $sid = New-Object System.Security.Principal.SecurityIdentifier($sidText)
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($sid, 'FullControl', 'Allow')))
    }
    Set-Acl -LiteralPath $Path -AclObject $acl
}

function Read-PrivateText([string]$Prompt) {
    $secureValue = Read-Host $Prompt -AsSecureString
    $pointer = [IntPtr]::Zero
    try {
        $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureValue)
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
    }
    finally {
        if ($pointer -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
        if ($secureValue) { $secureValue.Dispose() }
    }
}

try {
    $SourceDir = (Resolve-Path -LiteralPath $SourceDir).Path
    foreach ($item in @('pyproject.toml', 'telemetry_agent')) {
        if (-not (Test-Path -LiteralPath (Join-Path $SourceDir $item))) {
            throw "Falta $item en el proyecto de origen."
        }
    }
    $ResolvedPython = & $PythonExe -c 'import sys; assert sys.version_info >= (3, 10), "Se requiere Python >= 3.10"; print(sys.executable)'
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo ejecutar Python >= 3.10.' }
    $ResolvedPython = [string]$ResolvedPython
    foreach ($directory in @($InstallDir, $ConfigDir, $StateDir)) {
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
        Set-PrivateDirectory $directory
    }
    if (-not (Test-Path -LiteralPath $ConfigPath)) {
        if ([string]::IsNullOrWhiteSpace($ServerUrl)) {
            $ServerUrl = Read-Host 'URL del servidor (https://...)'
        }
        $uri = $null
        if (-not [Uri]::TryCreate($ServerUrl, [UriKind]::Absolute, [ref]$uri)) {
            throw 'URL inválida.'
        }
        $loopback = $uri.Host -in @('127.0.0.1', 'localhost', '[::1]', '::1')
        if (($uri.Scheme -notin @('https', 'http')) -or
            (($uri.Scheme -eq 'http') -and -not $loopback) -or
            $uri.UserInfo -or $uri.Query -or $uri.Fragment) {
            throw 'Use HTTPS. HTTP sólo se permite en loopback.'
        }
        $plainCode = $null
        $plainKey = $null
        try {
            $plainCode = [string](Read-PrivateText 'Código de instalación (Enter para inventario general)')
            if ($plainCode.Length -gt 256 -or $plainCode -match '[^\x21-\x7E]') {
                throw 'Código de instalación inválido: use texto ASCII sin espacios ni controles, de hasta 256 caracteres.'
            }
            $plainKey = ''
            if ([string]::IsNullOrEmpty($plainCode)) {
                $plainKey = [string](Read-PrivateText 'Clave general de inscripción (enrollment_key)')
                if ([string]::IsNullOrWhiteSpace($plainKey)) { throw 'La clave no puede estar vacía.' }
                if ($plainKey -match '[\x00-\x1F\x7F]') { throw 'La clave no puede contener caracteres de control.' }
            }
            $config = [ordered]@{
                server_url = $ServerUrl.TrimEnd('/')
                enrollment_key = $plainKey
                installation_code = $plainCode
                interval_seconds = 60
                state_path = (Join-Path $StateDir 'identity.json')
                timeout_seconds = 15
                max_backoff_seconds = 300
            }
            $json = $config | ConvertTo-Json
            [IO.File]::WriteAllText($ConfigPath, $json, (New-Object Text.UTF8Encoding($false)))
        }
        finally {
            $plainCode = $null
            $plainKey = $null
            $json = $null
            $config = $null
        }
    }
    else {
        Write-Host 'Actualización: se conservan configuración e identidad. No se reasigna el equipo a otra compañía, sede o grupo.'
    }
    Set-PrivateFile $ConfigPath
    $identity = Join-Path $StateDir 'identity.json'
    if (Test-Path -LiteralPath $identity) { Set-PrivateFile $identity }

    $StageDir = Join-Path $InstallDir ('.source-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $StageDir | Out-Null
    foreach ($item in @('pyproject.toml', 'README.md', 'LICENSE')) {
        $source = Join-Path $SourceDir $item
        if (Test-Path -LiteralPath $source) { Copy-Item -LiteralPath $source -Destination $StageDir }
    }
    # The packages contain Python sources only; local configuration/state stays out.
    foreach ($package in @('telemetry_agent')) {
        $packageSource = Join-Path $SourceDir $package
        foreach ($file in @(Get-ChildItem -LiteralPath $packageSource -Recurse -File -Filter '*.py')) {
            if ($file.FullName -match '[\\/]__pycache__[\\/]') { continue }
            $relative = $file.FullName.Substring($SourceDir.TrimEnd('\', '/').Length + 1)
            $target = Join-Path $StageDir $relative
            New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
            Copy-Item -LiteralPath $file.FullName -Destination $target
        }
    }
    $VenvPython = Join-Path $InstallDir 'venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $VenvPython)) {
        & $ResolvedPython -m venv (Join-Path $InstallDir 'venv')
        if ($LASTEXITCODE -ne 0) { throw 'No se pudo crear el entorno virtual.' }
    }
    $previousTask = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    if ($previousTask) { Stop-ScheduledTask -TaskName $TaskName }
    & $VenvPython -m pip install --upgrade "$($StageDir)[agent]"
    if ($LASTEXITCODE -ne 0) {
        if ($previousTask) { Start-ScheduledTask -TaskName $TaskName }
        throw 'No se pudo instalar el paquete del agente.'
    }
    if (Test-Path -LiteralPath $AppDir) { Remove-Item -LiteralPath $AppDir -Recurse -Force }
    Move-Item -LiteralPath $StageDir -Destination $AppDir
    $StageDir = $null
    $action = New-ScheduledTaskAction -Execute $VenvPython `
        -Argument ('-m telemetry_agent --config "{0}"' -f $ConfigPath) `
        -WorkingDirectory $StateDir
    $trigger = New-ScheduledTaskTrigger -AtStartup
    $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) `
        -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) `
        -StartWhenAvailable -MultipleInstances IgnoreNew `
        -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger `
        -Principal $principal -Settings $settings -Description 'Agente de telemetría de inventario' -Force | Out-Null
    Start-ScheduledTask -TaskName $TaskName
    Write-Host 'Agente instalado. Configuración e identidad existentes conservadas.'
    Write-Host "Estado: Get-ScheduledTaskInfo -TaskName '$TaskName'"
}
finally {
    if ($StageDir -and (Test-Path -LiteralPath $StageDir)) {
        Remove-Item -LiteralPath $StageDir -Recurse -Force
    }
}
